﻿structify\_net.scoring.get\_default\_scores
===========================================

.. currentmodule:: structify_net.scoring

.. autofunction:: get_default_scores