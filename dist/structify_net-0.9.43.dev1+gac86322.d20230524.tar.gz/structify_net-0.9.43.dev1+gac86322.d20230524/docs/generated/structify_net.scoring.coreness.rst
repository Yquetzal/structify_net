﻿structify\_net.scoring.coreness
===============================

.. currentmodule:: structify_net.scoring

.. autofunction:: coreness