﻿structify\_net.scoring.scores\_for\_generators
==============================================

.. currentmodule:: structify_net.scoring

.. autofunction:: scores_for_generators