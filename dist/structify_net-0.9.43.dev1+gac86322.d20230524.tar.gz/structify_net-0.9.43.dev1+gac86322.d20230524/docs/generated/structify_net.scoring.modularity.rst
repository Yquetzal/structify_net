﻿structify\_net.scoring.modularity
=================================

.. currentmodule:: structify_net.scoring

.. autofunction:: modularity