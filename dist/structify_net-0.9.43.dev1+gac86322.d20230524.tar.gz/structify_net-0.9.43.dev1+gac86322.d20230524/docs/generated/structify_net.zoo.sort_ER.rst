﻿structify\_net.zoo.sort\_ER
===========================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_ER