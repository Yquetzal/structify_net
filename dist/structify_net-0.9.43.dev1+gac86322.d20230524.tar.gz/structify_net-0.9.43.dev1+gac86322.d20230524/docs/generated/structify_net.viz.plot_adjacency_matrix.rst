﻿structify\_net.viz.plot\_adjacency\_matrix
==========================================

.. currentmodule:: structify_net.viz

.. autofunction:: plot_adjacency_matrix