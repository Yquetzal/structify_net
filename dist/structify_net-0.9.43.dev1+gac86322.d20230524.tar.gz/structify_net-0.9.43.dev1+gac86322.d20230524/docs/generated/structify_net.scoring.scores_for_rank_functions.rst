﻿structify\_net.scoring.scores\_for\_rank\_functions
===================================================

.. currentmodule:: structify_net.scoring

.. autofunction:: scores_for_rank_functions