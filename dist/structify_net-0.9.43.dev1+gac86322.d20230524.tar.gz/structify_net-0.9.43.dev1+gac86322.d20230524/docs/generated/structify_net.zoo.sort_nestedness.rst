﻿structify\_net.zoo.sort\_nestedness
===================================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_nestedness