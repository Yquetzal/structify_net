﻿structify\_net.zoo.sort\_stars
==============================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_stars