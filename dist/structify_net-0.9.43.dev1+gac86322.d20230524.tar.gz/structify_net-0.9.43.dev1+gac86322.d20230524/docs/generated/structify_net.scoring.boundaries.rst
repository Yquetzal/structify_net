﻿structify\_net.scoring.boundaries
=================================

.. currentmodule:: structify_net.scoring

.. autofunction:: boundaries