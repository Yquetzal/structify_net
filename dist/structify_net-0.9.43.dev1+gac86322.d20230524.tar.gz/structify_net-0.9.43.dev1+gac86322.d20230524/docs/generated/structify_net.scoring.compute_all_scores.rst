﻿structify\_net.scoring.compute\_all\_scores
===========================================

.. currentmodule:: structify_net.scoring

.. autofunction:: compute_all_scores