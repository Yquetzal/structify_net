﻿structify\_net.zoo.sort\_largest\_disconnected\_cliques
=======================================================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_largest_disconnected_cliques