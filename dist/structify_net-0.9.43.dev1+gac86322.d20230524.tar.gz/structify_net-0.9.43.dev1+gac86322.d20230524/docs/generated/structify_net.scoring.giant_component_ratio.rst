﻿structify\_net.scoring.giant\_component\_ratio
==============================================

.. currentmodule:: structify_net.scoring

.. autofunction:: giant_component_ratio