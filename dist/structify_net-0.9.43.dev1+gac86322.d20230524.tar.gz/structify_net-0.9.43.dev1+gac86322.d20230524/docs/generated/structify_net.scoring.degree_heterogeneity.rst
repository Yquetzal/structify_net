﻿structify\_net.scoring.degree\_heterogeneity
============================================

.. currentmodule:: structify_net.scoring

.. autofunction:: degree_heterogeneity