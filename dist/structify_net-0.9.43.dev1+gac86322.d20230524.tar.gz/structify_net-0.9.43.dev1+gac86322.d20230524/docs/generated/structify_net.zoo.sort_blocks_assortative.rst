﻿structify\_net.zoo.sort\_blocks\_assortative
============================================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_blocks_assortative