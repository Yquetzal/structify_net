﻿structify\_net.scoring.scores\_for\_graphs
==========================================

.. currentmodule:: structify_net.scoring

.. autofunction:: scores_for_graphs