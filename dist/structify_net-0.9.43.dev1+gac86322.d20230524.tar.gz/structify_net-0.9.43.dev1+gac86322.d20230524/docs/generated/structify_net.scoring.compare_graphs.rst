﻿structify\_net.scoring.compare\_graphs
======================================

.. currentmodule:: structify_net.scoring

.. autofunction:: compare_graphs