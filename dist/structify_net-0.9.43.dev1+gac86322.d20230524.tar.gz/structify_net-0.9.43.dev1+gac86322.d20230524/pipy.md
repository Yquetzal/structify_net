# Structify-net

This library allows to generate networks with a custom structure and a fix size