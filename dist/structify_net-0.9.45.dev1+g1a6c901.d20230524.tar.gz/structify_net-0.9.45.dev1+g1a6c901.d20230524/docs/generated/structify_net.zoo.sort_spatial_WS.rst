﻿structify\_net.zoo.sort\_spatial\_WS
====================================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_spatial_WS