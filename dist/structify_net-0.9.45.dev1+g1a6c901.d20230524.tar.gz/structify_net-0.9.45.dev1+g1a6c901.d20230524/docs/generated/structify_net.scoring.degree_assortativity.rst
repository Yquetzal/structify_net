﻿structify\_net.scoring.degree\_assortativity
============================================

.. currentmodule:: structify_net.scoring

.. autofunction:: degree_assortativity