﻿structify\_net.scoring.average\_clustering
==========================================

.. currentmodule:: structify_net.scoring

.. autofunction:: average_clustering