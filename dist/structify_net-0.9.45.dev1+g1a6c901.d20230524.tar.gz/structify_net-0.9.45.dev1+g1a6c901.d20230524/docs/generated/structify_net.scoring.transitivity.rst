﻿structify\_net.scoring.transitivity
===================================

.. currentmodule:: structify_net.scoring

.. autofunction:: transitivity