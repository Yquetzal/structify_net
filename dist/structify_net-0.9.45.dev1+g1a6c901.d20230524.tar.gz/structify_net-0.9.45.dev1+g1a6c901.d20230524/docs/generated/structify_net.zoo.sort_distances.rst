﻿structify\_net.zoo.sort\_distances
==================================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_distances