﻿structify\_net.scoring.average\_shortest\_path\_length
======================================================

.. currentmodule:: structify_net.scoring

.. autofunction:: average_shortest_path_length