﻿structify\_net.zoo.sort\_fractal\_hierarchical
==============================================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_fractal_hierarchical