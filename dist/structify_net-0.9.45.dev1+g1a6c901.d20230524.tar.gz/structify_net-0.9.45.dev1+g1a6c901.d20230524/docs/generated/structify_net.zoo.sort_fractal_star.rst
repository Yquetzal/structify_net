﻿structify\_net.zoo.sort\_fractal\_star
======================================

.. currentmodule:: structify_net.zoo

.. autofunction:: sort_fractal_star