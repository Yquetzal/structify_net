﻿structify\_net.scoring.has\_giant\_component
============================================

.. currentmodule:: structify_net.scoring

.. autofunction:: has_giant_component