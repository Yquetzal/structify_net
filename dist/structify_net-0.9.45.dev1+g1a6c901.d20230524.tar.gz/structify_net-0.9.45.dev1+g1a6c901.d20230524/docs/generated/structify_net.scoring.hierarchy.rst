﻿structify\_net.scoring.hierarchy
================================

.. currentmodule:: structify_net.scoring

.. autofunction:: hierarchy