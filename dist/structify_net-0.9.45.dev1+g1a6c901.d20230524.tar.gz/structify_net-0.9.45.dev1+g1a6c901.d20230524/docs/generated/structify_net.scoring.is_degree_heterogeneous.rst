﻿structify\_net.scoring.is\_degree\_heterogeneous
================================================

.. currentmodule:: structify_net.scoring

.. autofunction:: is_degree_heterogeneous