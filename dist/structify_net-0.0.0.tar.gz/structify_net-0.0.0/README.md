# structify_net
Generating random networks with diverse structures
